<!-- @file List of theme templates used in the Drupal Bootstrap base theme. -->
<!-- @defgroup -->
# Templates

List of theme templates used in the Drupal Bootstrap base theme.
