[![Build Status](https://travis-ci.org/ericpugh/drupal-views-bootstrap.svg?branch=8.x-3.x)](https://travis-ci.org/ericpugh/drupal-views-bootstrap)

CONTENTS OF THIS FILE
---------------------
   
 * Introduction
 * Requirements

INTRODUCTION
------------

The Views Bootstrap module adds styles to Views to output the results of a view 
as several common Twitter Bootstrap components.

 * For a full description of the module, visit the project page:
   https://www.drupal.org/project/views_bootstrap

REQUIREMENTS
------------

This module requires the following themes/modules:

 * Views (Core)
 * Bootstrap Theme (https://www.drupal.org/project/bootstrap)
